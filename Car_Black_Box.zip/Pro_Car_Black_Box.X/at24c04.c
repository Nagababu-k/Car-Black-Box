/*
 * File:   at240c4.c
 * Author: Nagababu
 *
 * Created on 4 March, 2024, 3:40 PM
 */


#include "at24c04.h"
#include "i2c.h"

unsigned char eeprom_at24c04_read(unsigned char addr) {
    unsigned char data;

    i2c_start();
    i2c_write(SLAVE_WRITE_EE);
    i2c_write(addr);
    i2c_rep_start();
    i2c_write(SLAVE_READ_EE);
    data = i2c_read(0);
    i2c_stop();

    return data;

}

void eeprom_at24c04_byte_write(unsigned char addr, char data) {
    i2c_start();
    i2c_write(SLAVE_WRITE_EE);
    i2c_write(addr);
    i2c_write(data);
    i2c_stop();
}

void eeprom_at24c04_str_write(unsigned char addr, char *str) {
    while (*str != '\0') {
        eeprom_at24c04_byte_write(addr, *str);
        addr++;
        str++;
    }
}

