/* 
 * File:   car_black_box.h
 * Author: Nagababu
 *
 * Created on 4 March, 2024, 3:43 PM
 */

#ifndef CAR_BLACK_BOX_H
#define	CAR_BLACK_BOX_H

// Function prototypes

// Display current time on the LCD screen.
void display_time(void);

// Display the default screen with event and speed.
void display_default_screen(char *event, unsigned char speed);

// Log a car event.
void log_car_event(char event[], unsigned char speed);

// Download log to the UART.
void download_log(void);

// Edit the current time.
void edit_time(unsigned char reset_flag, unsigned char key);

// Clear the LCD screen.
void clear_screen(void);

// View the log on the LCD screen.
char view_log(unsigned char reset_flag, unsigned char key);

// Clear the log memory.
void clear_log(unsigned char reset_flag);

// Display the login menu.
char login_menu(unsigned char reset_flag, unsigned char key);

// User login function.
char login(unsigned char reset_flag, unsigned char key);

// Change the password.
char change_password(unsigned char reset_flag, unsigned char key);

#endif	/* CAR_BLACK_BOX_H */