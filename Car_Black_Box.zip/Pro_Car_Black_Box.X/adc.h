/*
 * File:   adc.c
 * Author: Nagababu
 *
 * Created on 4 March, 2024, 3:42 PM
 */

#ifndef ADC_H
#define	ADC_H

void init_adc(void);
unsigned short read_adc(void);

#endif	/* ADC_H */


